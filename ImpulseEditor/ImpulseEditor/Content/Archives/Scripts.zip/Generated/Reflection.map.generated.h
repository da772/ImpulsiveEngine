#pragma once
#include "reflection/reflection.hpp"

	__REFLECTION__EXPORT__ void __ReflectionMap__loadGeneratedFiles(::refl::store::storage* storage) {};
	__REFLECTION__EXPORT__ void __ReflectionMap__unloadGeneratedFiles(::refl::store::storage* storage) {};