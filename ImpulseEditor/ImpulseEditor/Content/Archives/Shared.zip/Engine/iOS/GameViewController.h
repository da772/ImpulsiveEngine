#ifdef GE_PLATFORM_IOS
#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface GameViewController : GLKViewController

@end


@interface TouchableView : GLKView

@end

#endif
